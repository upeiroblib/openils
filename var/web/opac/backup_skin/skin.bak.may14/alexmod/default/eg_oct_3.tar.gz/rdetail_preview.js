/**
 *  Functions to enable Google books previews on Evergreen item pages.
 */
 
var googleIdentifier;
 
function rdetailCheckForPreview() {
  
  var p = document.createElement('p');
  p.appendChild( document.createTextNode( 'Loading...' ) );
  p.id = 'loading';
  $('rdetail_excerpt_div').appendChild(p);

  if ( trimStr( getText( $('rdetail_isbn' ) ) ) != '' ) {
    searchForPreview( getText( $('rdetail_isbn' ) ) );
  } else {
    queryStr = getText( $('rdetail_author') ) + getText( $('rdetail_title' ) );
    
    // Set up the request to Google Book Search to search for a result by title and author
    var script = document.createElement("script");
    script.src = 'http://books.google.com/books/feeds/volumes?q=' 
      + encodeURIComponent( queryStr ) + '&min-viewability=partial'
      + '&alt=json-in-script&callback=titleAuthorSearchCallback';
    script.type = "text/javascript";
    document.getElementsByTagName("head")[0].appendChild(script);
    
  }
}


function titleAuthorSearchCallback(root) {
  // Find the identifier of the first embeddable match
  // If none found, report an error
  var feed = root.feed;
  var entries = feed.entry || [];

  for (var i = 0; i < entries.length; ++i) {
    var entry = entries[i];
    var embeddableValue = entry.gbs$embeddability.value;
          
    var isEmbeddable = (embeddableValue == 
      'http://schemas.google.com/books/2008#embeddable');
    var identifier = entry.dc$identifier[0].$t;

//    identifier = identifier.substr( 5, identifier.length );

    if (isEmbeddable) {
      googleIdentifier = identifier;
      searchForPreview(identifier);
      return;
    }
  }

  showStatus('Could not find a match');
}
 
/**
 *
 * @param {DOM object} query The form element containing the
 *                     input parameters "isbns"
 */
function searchForPreview( isbn ) {

  // Delete any previous Google Booksearch JSON queries.
  var jsonScript = document.getElementById("jsonScript");
  if (jsonScript) {
    jsonScript.parentNode.removeChild(jsonScript);
  }
  // Add a script element with the src as the user's Google Booksearch query. 
  // JSON output is specified by including the alt=json-in-script argument
  // and the callback funtion is also specified as a URI argument.
  var scriptElement = document.createElement("script");

  scriptElement.setAttribute("id", "jsonScript");
  scriptElement.setAttribute("src",
      "http://books.google.com/books?bibkeys=" + 
      cleanISBN( isbn ) + "&jscmd=viewapi&callback=previewCallback");
  scriptElement.setAttribute("type", "text/javascript");
  // make the request to Google booksearch
  document.documentElement.firstChild.appendChild(scriptElement);
}

/**
 * This function is the call-back function for the JSON scripts which 
 * executes a Google book search response.
 *
 * @param {JSON} booksInfo is the JSON object pulled from the Google books service.
 */
function previewCallback(bookInfo) {
  // Clear any old data to prepare to display the Loading... message.
  var div = document.getElementById("rdetail_excerpt_div");
  var book;
  
  for ( i in bookInfo ) {
    book = bookInfo[i];
  }
//  if (div.firstChild) { 
//    div.removeChild(div.firstChild);    

//  }
 
  if ( !book ) {
    return;
  }

  if ( book.preview != "noview" ) {
    if ( book.preview == 'full' ) {
      setText( $('rdetail_excerpt_link_a'), 'Full Text' );
      $('rdetail_excerpt_link_a').title = 'See the full text of this book.';      
    }

    // Add a button below the book cover image to load the preview.
    badge = document.createElement( 'img' );
    badge.src = 'http://books.google.com/intl/en/googlebooks/images/gbs_preview_button1.gif';
    badge.title = 'Show a preview of this book from Google Book Search';
    badge.style.border = 0;
    badgelink = document.createElement( 'a' );
    badgelink.href = 'javascript:rdetailShowExtra("excerpt");';
    badgelink.appendChild( badge );
    $('rdetail_image_cell').appendChild( badgelink );

	
    
    unHideMe( $('rdetail_excerpt_link' ) );
    $('rdetail_excerpt_div').style.height = 600;
  }

//  document.getElementById('rdetail_excerpt_div').appendChild(mainDiv);

}

/**
 *  This is called when the user clicks on the 'Excerpt' link.  We assume
 *  a preview is available from google is this link was made visible.
 *  The google viewer API should have been loaded in page_rdetail.xml
 */
function rdetailDisplayPreview() {
  previewPane = $('rdetail_excerpt_div');
  if ( $('rdetail_excerpt_div').getAttribute('loaded') == null ||  $('rdetail_excerpt_div').getAttribute('loaded') == "false" ) {
    google.load("books", "0", {"callback" : rdetailVIewerLoadCallback} );
//  google.setOnLoadCallback( rdetailVIewerLoadCallback );
    $('rdetail_excerpt_div').setAttribute('loaded', 'true');
  }
}

function rdetailVIewerLoadCallback() {

  if ( googleIdentifier == null ) {
    googleIdentifier =  trimStr( getText( $('rdetail_isbn' ) ) );
  }

  var viewer = new google.books.DefaultViewer(document.getElementById('rdetail_excerpt_div'));
//  if ( googleIdentifier.indexOf ( ':' ) == -1 ) {
//    googleIdentifier = 'isbn:'+ googleIdentifier;
//  }
  viewer.load( googleIdentifier );
  
}


























